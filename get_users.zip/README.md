# TP 3 - Grupo 10

## Rubrica

| Legajo | Nombre        | Porcentaje |
|--------|---------------|------------|
| 59290  | Patrick Dey   | 25%        |
| 60052  | Santos Rosati | 25%        |
| 60242  | Camila Sierra | 25%        |
| 60509  | Julian Arce   | 25%        |

## Modulos
- VPC
- Api Gateway
- Lambda Functions
- IAM Role (para las lambda functions)
- Aurora Serverless
- s3 Buckets
- CloudFront
