exports.handler = async (event) => {
	const { Client } = require('pg');

	const id = event.pathParameters.id;
	const query = {
		text: 'SELECT * FROM timesheets WHERE id = $1',
		values: [id]
	};

	const client = new Client({
		user: 'postgres',
		password: 'rootroot',
		host: process.env.DB_HOST,
		port: process.env.DB_PORT,
		database: process.env.DB_NAME
	});

	await client.connect();

	const result = await client.query(query);
	const resultString = JSON.stringify(result);

	client.end();

	const response = {
		statusCode: 200,
		body: resultString
	};

	return response;
};
